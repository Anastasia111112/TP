import java.util.*;

class Dictionary {

    private final Map<String, Set<String>> translations = new HashMap<>();

    public void add(String word, String translation) {
        translations.computeIfAbsent(word, k -> new TreeSet<>()).add(translation);
    }

    public Set<String> get(String word) {
        return translations.getOrDefault(word, Collections.emptySet());
    }

    public void printDictionary() {
        for (Map.Entry<String, Set<String>> entry : translations.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}
