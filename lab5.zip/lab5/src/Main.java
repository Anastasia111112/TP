
import java.util.Map;

public class Main {

    public static void main(String[] args) {

        Dictionary translator = new Dictionary();

        translator.add("apple", "яблоко");
        translator.add("apple", "апфель");
        translator.add("orange", "апельсин");
        translator.add("grape", "виноград");
        translator.add("grape", "гроно");
        translator.add("apple", "яблоко");

        translator.printDictionary();

        System.out.println("\nTranslations for 'apple': " + translator.get("apple"));
        System.out.println("Translations for 'grape': " + translator.get("grape"));

        String[] words = {
                "apple", "orange", "banana", "apple", "kiwi",
                "orange", "grape", "banana", "apple", "peach",
                "kiwi", "grape", "melon", "apple", "pear",
                "grape", "melon", "pear", "kiwi", "peach"
        };

        String[] russianWords = new String[]{"яблоко", "банан", "яблоко", "апельсин", "киви", "манго", "слива", "слива", "апельсин", "киви"};
        Map<String, Integer> wordCount = WordAnalyzer.processWords(russianWords);
        System.out.println("\nУникальные слова и их количество: ");
        System.out.println(wordCount.entrySet());
    }
}