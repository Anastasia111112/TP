import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== 1 задание ===");
        List<String> words = new ArrayList<>(Arrays.asList("abc", "Стол", "яя", "яя", "abc", "Тетрадь", "Окно", "Стул", "Лампа", "Кровать", "Стол"));
        findMostFrequentWords(words);

        List<Student> students = new ArrayList<>(Arrays.asList(
                new Student("Иван", "Иванов", 2, 3.5),
                new Student("Петр", "Петров", 1, 3.1),
                new Student("Анна", "Смирнова", 3, 4.8),
                new Student("Ольга", "Кузнецова", 2, 4.0),
                new Student("Владимир", "Сидоров", 1, 2.9)
        ));

        System.out.println("=== 2 задание ===");
        printNOutsiders(students, 3);
    }

    public static void findMostFrequentWords(List<String> words) {
        words.stream()
                .map(String::toLowerCase)
                .collect(groupingBy(Function.identity(), counting()))
                .entrySet().stream()
                .collect(groupingBy(Map.Entry::getValue, mapping(Map.Entry::getKey, toCollection(TreeSet::new))))
                .entrySet().stream()
                .max(Map.Entry.comparingByKey())
                .map(entry -> entry.getValue().stream().sorted(Comparator.reverseOrder()).collect(joining(", ")))
                .map(mostFrequent -> "Наиболее часто встречающиеся слова: " + mostFrequent)
                .ifPresentOrElse(System.out::println, () -> System.out.println("Нет повторяющихся слов"));
    }

    public static void printNOutsiders(List<Student> students, int n) {
        System.out.println(students.stream()
                .sorted(Comparator.comparingDouble(Student::getAverageGrade))
                .limit(n)
                .map(Student::getLastName)
                .sorted()
                .collect(Collectors.joining(", ", n + " самых плохих студентов: ", ";")));
    }
}

class Student {
    private String firstName;
    private String lastName;
    private int course;
    private double averageGrade;

    public Student(String firstName, String lastName, int course, double averageGrade) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.course = course;
        this.averageGrade = averageGrade;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getCourse() {
        return course;
    }

    public double getAverageGrade() {
        return averageGrade;
    }
}
