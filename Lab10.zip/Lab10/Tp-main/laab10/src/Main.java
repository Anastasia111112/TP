import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class Main {
    private static final String URL = "jdbc:postgresql://localhost:5432/laab10";
    private static final String USER = "postgres";
    private static final String PASSWORD = "";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement statement = connection.createStatement()) {

            connection.setAutoCommit(true);
            System.out.println("Подключение к базе данных успешно установлено.");

            statement.execute("DROP TABLE IF EXISTS public.progress;");
            statement.execute("DROP TABLE IF EXISTS public.subjects;");
            statement.execute("DROP TABLE IF EXISTS public.students;");
            System.out.println("Старые таблицы удалены.");

            statement.execute("CREATE TABLE IF NOT EXISTS students " +
                    "(id SERIAL NOT NULL PRIMARY KEY, " +
                    "name VARCHAR(30) NOT NULL, " +
                    "passport_series VARCHAR(4) NOT NULL, " +
                    "passport_number VARCHAR(6) NOT NULL, " +
                    "UNIQUE (passport_series, passport_number));");
            System.out.println("Таблица students создана.");

            statement.execute("CREATE TABLE IF NOT EXISTS subjects " +
                    "(id SERIAL NOT NULL PRIMARY KEY, " +
                    "name VARCHAR(50) NOT NULL);");
            System.out.println("Таблица subjects создана.");

            statement.execute("CREATE TABLE IF NOT EXISTS progress " +
                    "(id SERIAL NOT NULL PRIMARY KEY, " +
                    "student_id INT NOT NULL REFERENCES students(id) ON DELETE CASCADE, " +
                    "subject_id INT NOT NULL REFERENCES subjects(id), " +
                    "grade INT NOT NULL CHECK (grade >= 2 AND grade <= 5));");
            System.out.println("Таблица progress создана.");

            int studentsInserted = statement.executeUpdate("INSERT INTO students (name, passport_series, passport_number) VALUES " +
                    "('Алексей', '3310', '335678'), " +
                    "('Сергей', '3322', '342345'), " +
                    "('Данил', '3333', '348945'), " +
                    "('Роман', '3444', '234567'), " +
                    "('Артем', '3355', '345678'), " +
                    "('Тихон', '3300', '890123');");
            if (studentsInserted > 0) {
                System.out.println("Данные в таблицу students добавлены.");
            }

            int subjectsInserted = statement.executeUpdate("INSERT INTO subjects (name) VALUES " +
                    "('Математика'), " +
                    "('Физика'), " +
                    "('Химия'), " +
                    "('Биология');");
            if (subjectsInserted > 0) {
                System.out.println("Данные в таблицу subjects добавлены.");
            }

            int progressInserted = statement.executeUpdate("INSERT INTO progress (student_id, subject_id, grade) VALUES " +
                    "(1, 1, 4), " +
                    "(1, 2, 3), " +
                    "(2, 1, 5), " +
                    "(2, 3 , 4), " +
                    "(3, 2, 2), " +
                    "(4, 1, 3), " +
                    "(5, 4, 5), " +
                    "(6, 3, 4);");
            if (progressInserted > 0) {
                System.out.println("Данные в таблицу progress добавлены.");
            }

            executeQueries(statement);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void executeQueries(Statement statement) throws SQLException {
        System.out.println("Студенты, сдавшие Математику на оценку выше 3:");
        try (ResultSet res = statement.executeQuery("SELECT s.name FROM students s " +
                "INNER JOIN progress p ON s.id = p.student_id " +
                "INNER JOIN subjects sub ON p.subject_id = sub.id " +
                "WHERE sub.name = 'Математика' AND p.grade > 3;")) {
            while (res.next()) {
                System.out.println(res.getString(1));
            }
        }

        System.out.println("Средний балл по предмету 'Математика':");
        try (ResultSet res = statement.executeQuery("SELECT AVG(p.grade) AS avg_grade FROM progress p " +
                "INNER JOIN subjects sub ON p.subject_id = sub.id " +
                "WHERE sub.name = 'Математика';")) {
            if (res.next()) {
                System.out.println(res.getDouble(1));
            }
        }

        System.out.println("Средний балл студента 'Алексей':");
        try (ResultSet res = statement.executeQuery("SELECT AVG(p.grade) AS avg_grade FROM progress p " +
                "INNER JOIN students s ON p.student_id = s.id " +
                "WHERE s.name = 'Алексей';")) {
            if (res.next()) {
                System.out.println(res.getDouble(1));
            }
        }

        System.out.println("Три предмета, которые сдали наибольшее количество студентов:");
        try (ResultSet res = statement.executeQuery("SELECT sub.name, COUNT(DISTINCT p.student_id) AS student_count " +
                "FROM progress p " +
                "INNER JOIN subjects sub ON p.subject_id = sub.id " +
                "GROUP BY sub.name " +
                "ORDER BY student_count DESC " +
                "LIMIT 3;")) {
            while (res.next()) {
                System.out.println(res.getString(1) + ": " + res.getInt(2) + " студентов");
            }
        }

        System.out.println("Студенты, сдавшие по оценке 3 по любому предмету:");
        try (ResultSet res = statement.executeQuery("SELECT s.name, sub.name, p.grade " +
                "FROM students s " +
                "INNER JOIN progress p ON s.id = p.student_id " +
                "INNER JOIN subjects sub ON p.subject_id = sub.id " +
                "WHERE p.grade = 3;")) {
            while (res.next()) {
                System.out.println(res.getString(1) + " сдал(а) " + res.getString(2) + " на оценку " + res.getInt(3));
            }
        }
    }
}
