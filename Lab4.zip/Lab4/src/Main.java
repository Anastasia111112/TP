import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
/*
        System.out.println("1 задание");
        Integer[] arr1 = {51, 13, 0, 7, 3, 16};
        String[] arr2 = {"молоко", "собака", "автомобиль", "инженерия", "поэзия"};
        System.out.println(Arrays.toString(arr1));
        swapElements(arr1, 1, 4);
        System.out.println(Arrays.toString(arr1));
        System.out.println(Arrays.toString(arr2));
        swapElements(arr2, 2, 3);
        System.out.println(Arrays.toString(arr2));

        System.out.println("2 задание");
        List<String> list = convertToList(arr2);
        System.out.println(list);
*/

        System.out.println("3 задание");
        Box<Apple> appleBox = new Box<>(new Apple());
        Box<Orange> orangeBox = new Box<>(new Orange());
        Box<Banana> bananaBox = new Box<>(new Banana(), new Banana(), new Banana());
        Box<Lemon> lemonBox = new Box<>(new Lemon(), new Lemon(), new Lemon());
        //новый интерфейс BananaBox
        BananaBox bananaBox1 = new Box<>(new Banana(), new Banana(), new Banana());
        bananaBox1.addFruit(new Banana());

        bananaBox.printBox();
        bananaBox.addFruit(new Banana());
        bananaBox.printBox();

        System.out.println("\nСодержимое коробок:");
        /*appleBox.printBox();
        orangeBox.printBox();
        bananaBox.printBox();
        lemonBox.printBox();*/
    }

    private static <T> void swapElements(T[] array, int index1, int index2) {
        T temp = array[index1];
        array[index1] = array[index2];
        array[index2] = temp;
    }

    private static <V> List<V> convertToList(V[] array) {
        return Arrays.asList(array);
    }
}
