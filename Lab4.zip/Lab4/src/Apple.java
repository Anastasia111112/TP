

class Apple extends Fruit {
    public Apple() {
        super(1.0f);
    }
}
