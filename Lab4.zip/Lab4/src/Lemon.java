class Lemon extends Fruit {
    public Lemon() {
        super(2.0f);
    }
}