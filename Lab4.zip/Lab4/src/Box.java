import java.util.ArrayList;
import java.util.List;

public class Box<L extends Fruit> implements BananaBox {
    private final List<L> list = new ArrayList<>();
    private boolean containsLemon = false;
    private boolean containsBanana = false;

    @SafeVarargs
    public Box(L... fruits) {
        for (L fruit : fruits) {
            addFruit(fruit);
        }
    }

    public void addFruit(int i) {
        //this.list.get(0).getClass().newInstance();
        for (int j = 0; j < i; j++) {
            try {
                this.list.add((L) this.list.get(j).getClass().newInstance());
            } catch (InstantiationException e) {
                throw new RuntimeException(e);
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }
          /*  try {
                this.list.add((L) this.list.get(0).getClass().newInstance());
            } catch (InstantiationException e) {
                throw new RuntimeException(e);
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }*/
    }

    public float getWeight() {
        float weight = 0.0f;
        for (L fruit : list) {
            weight += fruit.getWeight();
        }
        return weight;
    }

    @Override
    public void addFruit() {
    }

    public void addFruit(L fruit) {
        this.list.add(fruit);
 /*     if (fruit instanceof Banana) {
            if (!containsBanana) {
                containsBanana = true;
            }
            list.add(fruit);
            return;
        }

        if (fruit instanceof Lemon) {
            containsLemon = true;
        }
        list.add(fruit);*/
    }

/*
    public void addFruit(List<L> fruits) {
        boolean bananaFound = false;

        for (L fruit : fruits) {
            if (fruit instanceof Banana) {
                bananaFound = true;
                break;
            } else if (fruit instanceof Lemon) {
                containsLemon = true;
            }
        }

        if (bananaFound) {
            return;
        }

        list.addAll(fruits);
    }
*/

    public void transferFruits(Box<L> otherBox) {
        if (containsBanana) {
            System.out.println("Пересыпание не разрешено: эта коробка содержит бананы.");
            return;
        }

        otherBox.list.addAll(this.list);
        this.list.clear();
    }

    public boolean canCompare() {
        if (containsLemon) {
            System.out.println("Сравнение не разрешено: эта коробка содержит лимоны.");
            return false;
        }
        return true;
    }

    public void printBox() {
        if (list.isEmpty()) {
            System.out.println("Коробка пуста");
        } else {
            System.out.println("Коробка содержит:");
            for (L fruit : list) {
                System.out.println(fruit);
            }
        }
    }
}