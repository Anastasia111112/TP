class Orange extends Fruit {
    public Orange() {
        super(1.5f);
    }
}