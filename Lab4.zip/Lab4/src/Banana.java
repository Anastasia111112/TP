class Banana extends Fruit {
    public Banana() {
        super(1.2f);
    }
}