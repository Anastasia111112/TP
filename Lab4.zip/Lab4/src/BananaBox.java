public interface BananaBox {
    void addFruit();
}
