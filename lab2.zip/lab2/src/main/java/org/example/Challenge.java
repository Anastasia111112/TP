package org.example;

public interface Challenge {
    boolean isCan(Participant participant);
}
