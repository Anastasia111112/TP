package org.example;

public class Cat implements Participant {
    private int maxHeight;
    private int maxLenght;
    private String name;
    private int superJumpCount;
    private boolean superJumpUsed;

    public Cat(int maxHeight, int maxLenght, String name) {
        this.maxHeight = maxHeight;
        this.maxLenght = maxLenght;
        this.name = name;
        this.superJumpCount = 1;
    }

    @Override
    public boolean jump(int height) {
        if (height <= maxHeight) {
            System.out.println("Кот " + this.name + " прыгнул " + height + "м");
            return true;
        } else if (!superJumpUsed && superJumpCount > 0) {
            return superJump(height);
        } else {
            System.out.println("Кот " + this.name + " не смог прыгнуть " + height + "м и выбывает");
            return false;
        }
    }

    @Override
    public boolean run(int dist) {
        if (dist <= maxLenght) {
            System.out.println("Кот " + this.name + " пробежал " + dist + "м");
            return true;
        } else {
            System.out.println("Кот " + this.name + " не смог пробежать " + dist + "м и выбывает");
            return false;
        }
    }

    private boolean superJump(int height) {
        System.out.println("Кот " + this.name + " использовал экстра-прыжок и прыгнул " + height + "м");
        superJumpUsed = true;
        return true;
    }

    public String getName() {
        return name;
    }
}