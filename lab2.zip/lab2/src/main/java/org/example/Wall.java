package org.example;

public class Wall implements Challenge{
    String name;

    public Wall(WallHeight wallHeight) {
        this.name = wallHeight.getTitle();
        this.wallHeight = wallHeight.getHeight();
    }
    int wallHeight;

    @Override
    public boolean isCan(Participant participant) {
        if (participant.jump(wallHeight)) {
            return true;
        } else {
            return false;
        }
    }
}