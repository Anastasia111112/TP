package org.example;

public class Robot implements Participant {
    private int maxHeight;
    private int maxLenght;
    private String name;
    private int superRunCount;
    private boolean superRunUsed;

    public Robot(int maxHeight, int maxLenght, String name) {
        this.maxHeight = maxHeight;
        this.maxLenght = maxLenght;
        this.name = name;
        this.superRunCount = 3;
    }

    @Override
    public boolean run(int dist) {
        if (dist <= maxLenght) {
            System.out.println("Робот " + this.name + " пробежал " + dist + "м");
            return true;
        } else if (!superRunUsed && superRunCount > 0) {
            return superRun(dist);
        } else {
            System.out.println("Робот " + this.name + " не смог пробежать " + dist + "м и выбывает");
            return false;
        }
    }

    @Override
    public boolean jump(int height) {
        if (height <= maxHeight) {
            System.out.println("Робот " + this.name + " перепрыгнул " + height + "м");
            return true;
        } else {
            System.out.println("Робот " + this.name + " не смог перепрыгнуть " + height + "м и выбывает");
            return false;
        }
    }

    private boolean superRun(int dist) {
        System.out.println("Робот " + this.name + " использовал экстра-ускорение и пробежал " + dist + "м");
        superRunUsed = true;
        return true;
    }

    public String getName() {
        return name;
    }
}
