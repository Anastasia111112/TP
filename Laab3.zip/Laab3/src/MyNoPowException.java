class MyNoPowException extends Exception {
    public MyNoPowException(String message) {
        super(message);
    }
}