
    class MyArrayDataException extends Exception {
        public MyArrayDataException(String message) {
            super(message);
        }
    }

