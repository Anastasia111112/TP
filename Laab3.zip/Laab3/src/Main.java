import java.util.ArrayList;
import java.util.List;

public class Main {

    private static final String[][] array = {
            {"256п", "66", "3", "25"},
            {"345", "36", "125", "49"},
            {"9", "1000", "121", "12"},
            {"13", "14", "15","16"}
    };

    public static void main(String[] args) {
        try {
            processArray(array);
        } catch (MyArraySizeException | MyArrayDataException | MyNoPowException | MyLychrelException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static int processArray(String[][] array) throws MyArraySizeException, MyArrayDataException, MyNoPowException, MyLychrelException {

        StringBuilder errors = new StringBuilder();
        List<Integer> validSquares = new ArrayList<>();
        List<Integer> validCubes = new ArrayList<>();

        boolean sizeError = false;

        if (array.length != 4) {
            throw new MyArraySizeException("Массив должен содержать 4 строки.");
        }
        for (String[] row : array) {
            if (row.length != 4) {
                throw new MyArraySizeException("Массив должен содержать 4 столбца.");
            }
        }

        int sum = 0;
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                try {
                    sum+=Integer.parseInt(array[i][j]);
                } catch (NumberFormatException e) {
                    throw new MyArrayDataException("В ячейке [" + i + "][" + j + "] содержится нечисловое значение: " + array[i][j]);
                }
            }
        }



        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                try {
                    int value = Integer.parseInt(array[i][j]);

                    if (isLychrel(value)) {
                        throw new MyLychrelException("Число в ячейке [" + i + "][" + j + "] является числом Лихрела: " + value );
                    }
                    if (!isSquare(value) && !isCube(value)) {
                        try {
                            //System.out.println("Число в ячейке [" + i + "][" + j + "] не является допустимым квадратом или кубом: " + value);
                            throw new MyNoPowException("Число в ячейке [" + i + "][" + j + "] не является допустимым квадратом или кубом: " + value );
                        } catch (MyNoPowException e) {
                            e.printStackTrace();
                            // for (int col = 0; col < array[i].length; col++) {
                            //System.out.println("Число в ячейке [" + i + "][" + col + "] не является допустимым квадратом или кубом: " + array[i][col]);
                        }
                    }
                    // }

                    if (isSquare(value)) {
                        validSquares.add(value);
                    } else if (isCube(value)) {
                        validCubes.add(value);
                    }

                    sum += value;

                } catch (NumberFormatException e) {
                    throw new MyArrayDataException("В ячейке [" + i + "][" + j + "] содержится нечисловое значение: " + array[i][j]);
                }
            }
        }


        System.out.println("Допустимые квадраты из массива: " + validSquares);
        System.out.println("Допустимые кубы из массива: " + validCubes);
        System.out.println("Сумма равна: " + sum);

        return sum;
    }

    private static boolean isLychrel(int number) {
        if (number < 0 || number > 1000) {
            return false;
        }

        int maxIterations = 50;
        for (int i = 0; i < maxIterations; i++) {
            number = reverseAndAdd(number);
            if (isPalindrome(number)) {
                return false;
            }
        }

        return true;
    }

    private static boolean isPalindrome(int number) {
        String str = Integer.toString(number);
        String reversed = new StringBuilder(str).reverse().toString();
        return str.equals(reversed);
    }

    private static int reverseAndAdd(int number) {
        String str = Integer.toString(number);
        String reversedStr = new StringBuilder(str).reverse().toString();
        return number + Integer.parseInt(reversedStr);
    }

    private static boolean isSquare(int number) {
        int sqrt = (int) Math.sqrt(number);
        return sqrt * sqrt == number;
    }

    private static boolean isCube(int number) {
        int cbrt = (int) Math.cbrt(number);
        return cbrt * cbrt * cbrt == number;
    }
}