class MyLychrelException extends Exception {
    public MyLychrelException(String message) {
        super(message);
    }
}