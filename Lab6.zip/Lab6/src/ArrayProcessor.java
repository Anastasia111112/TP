import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

class ArrayProcessor {
    private final int size;

    public ArrayProcessor(int size) {
        this.size = size;
    }

    public void processSingleThread() {
        float[] arr = new float[size];
        fillArrayWithOnes(arr);

        long start = System.currentTimeMillis();
        for (int i = 0; i < arr.length; i++) {
            arr[i] = calculateNewValue(arr[i], i);
        }
        long end = System.currentTimeMillis();

        System.out.println("Время выполнения в одном потоке: " + (end - start) + " мс");
        System.out.println("Первый элемент: " + arr[0]);
        System.out.println("Последний элемент: " + arr[arr.length - 1]);
    }

    public void processMultiThread(int desiredThreads) {
        float[] arr = new float[size];
        fillArrayWithOnes(arr);

        long start = System.currentTimeMillis();
        int actualThreadCount = adjustThreadCount(desiredThreads);
        int partSize = size / actualThreadCount;

        ExecutorService executor = Executors.newFixedThreadPool(actualThreadCount);
        for (int i = 0; i < actualThreadCount; i++) {
            final int startIdx = i * partSize;
            final int endIdx = (i == actualThreadCount - 1) ? size : (i + 1) * partSize;
            final int threadNumber = i + 1;

            boolean isLastPart = (i == actualThreadCount - 1);

            executor.submit(() -> {
                processPart(arr, startIdx, endIdx, threadNumber, isLastPart);
            });
        }

        executor.shutdown();
        try {
            executor.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        long end = System.currentTimeMillis();
        System.out.println("Время выполнения в нескольких потоках: " + (end - start) + " мс");
    }

    private void fillArrayWithOnes(float[] arr) {
        for (int i = 0; i < arr.length; i++) {
            arr[i] = 1.0f;
        }
    }

    private float calculateNewValue(float value, int index) {
        return (float) (value * Math.sin(0.2f + index / 5.0) * Math.cos(0.2f + index / 5.0) * Math.cos(0.4f + index / 2.0));
    }

    private void processPart(float[] arr, int startIdx, int endIdx, int threadNumber, boolean isLastPart) {
        long start = System.currentTimeMillis();
        for (int j = startIdx; j < endIdx; j++) {
            arr[j] = calculateNewValue(arr[j], j);
        }
        long end = System.currentTimeMillis();

        if (isLastPart) {
            if (arr[startIdx] == arr[endIdx - 1]) {
                System.out.printf("Массив, обработанный потоком %d: [%f]%n", threadNumber, arr[startIdx]);
            } else {
                System.out.printf("Массив, обработанный потоком %d: [%f, %f]%n", threadNumber, arr[startIdx], arr[endIdx - 1]);
            }
        }
        }



    private int adjustThreadCount(int desiredThreads) {
        if (size % desiredThreads == 0) {
            return desiredThreads;
        }

        for (int threads = desiredThreads + 1; threads <= size; threads++) {
            if (size % threads == 0) {
                return threads;
            }
        }

        return desiredThreads;
    }
}