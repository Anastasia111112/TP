import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class Main {
    public static void main(String[] args) {
        int arraySize = 60_000_003;
        ArrayProcessor processor = new ArrayProcessor(arraySize);

        System.out.println("Обработка в одном потоке:");
        processor.processSingleThread();

        System.out.println("\nОбработка в нескольких потоках:");
        processor.processMultiThread(6);
    }
}
