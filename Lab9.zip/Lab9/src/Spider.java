
@Table(title = "Spider")
public class Spider {

    @Column
    private String name;

    @Column
    private String age;

    @Column
    private int maxRunDistance;

    @Column
    private String woolLength;


    public Spider(String name, String age, int maxRunDistance, String woolLength) {
        this.name = name;
        this.age = age;
        this.maxRunDistance = maxRunDistance;
        this.woolLength = woolLength;
    }
}
