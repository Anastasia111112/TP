
public class Main {
    public static void main(String[] args) throws Exception {
        Spider spider = new Spider("HouseSpider", "2", 50, "MEDIUM");
        Spider spider1 = new Spider("GardenSpider", "1", 30, "LOW");

        Crab crab = new Crab("BlueCrab", "4", 100, Crab.ClawSize.SMALL);
        Crab crab1 = new Crab("RockCrab", "3", 80, Crab.ClawSize.LARGE);


        Fly fly = new Fly("HouseFly", "1", 10, "LOW");
        Fly fly1 = new Fly("FruitFly", "1", 5, "LOW");

        AnnotationProcessor.createTable(spider);
        AnnotationProcessor.createTable(crab);
        AnnotationProcessor.createTable(fly);

        AnnotationProcessor.insertIntoTable(spider);
        AnnotationProcessor.insertIntoTable(spider1);


        AnnotationProcessor.insertIntoTable(crab);
        AnnotationProcessor.insertIntoTable(crab1);

        AnnotationProcessor.insertIntoTable(fly);
        AnnotationProcessor.insertIntoTable(fly1);
    }
}
