

@Table(title = "Crab124")
public class Crab {

    public enum ClawSize {
        SMALL, MEDIUM, LARGE;

        public String getClawSize() {
            return this.toString();
        }
    }


    @Column
    private String name;

    @Column
    private String age;

    @Column
    private int maxSwimDistance;

    @Column
    private ClawSize clawSize;

    public Crab(String name, String age, int maxSwimDistance, ClawSize clawSize) {
        this.name = name;
        this.age = age;
        this.maxSwimDistance = maxSwimDistance;
        this.clawSize = clawSize;
    }

    //    public Crab(String name, String age, int maxSwimDistance,  clawSize) {
//        this.name = name;
//        this.age = age;
//        this.maxSwimDistance = maxSwimDistance;
//        this.clawSize = clawSize;
//    }
}
