
@Table(title = "Fly")
public class Fly {

    @Column
    private String name;

    @Column
    private String age;

   @Column
    private int wingSpan;


    public Fly(String name, String age, int wingSpan, String low) {
        this.name = name;
        this.age = age;
        this.wingSpan = wingSpan;
    }
}
